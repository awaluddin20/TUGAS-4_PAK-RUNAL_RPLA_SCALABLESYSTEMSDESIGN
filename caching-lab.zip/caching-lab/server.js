const express = require('express');
const Redis = require('ioredis');
const path = require('path');

const app = express();
const redis = new Redis({
    host: 'redis', // Sesuai dengan nama service di docker-compose
    port: 6379
});

app.use(express.json());

// Simulasi Database Lambat (Butuh waktu 2 detik untuk ambil data)
const getComplexDataFromDatabase = () => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                timestamp: new Date().toLocaleTimeString(),
                message: "Data berhasil diambil dari Database Utama (Proses Berat)!"
            });
        }, 2000); 
    });
};

// Endpoint Pengujian Strategi Caching
app.get('/api/data', async (req, res) => {
    const cacheKey = 'dashboard:data';

    try {
        // 1. Coba ambil dari Redis Cache
        const cachedData = await redis.get(cacheKey);

        if (cachedData) {
            // JIKA CACHE HIT
            return res.json({
                source: 'Redis Cache (Cache Hit)',
                data: JSON.parse(cachedData)
            });
        }

        // 2. JIKA CACHE MISS -> Ambil dari Database Lambat
        const freshData = await getComplexDataFromDatabase();

        // 3. Simpan ke Redis dengan TTL 15 Detik (Cache Invalidation Strategy)
        await redis.set(cacheKey, JSON.stringify(freshData), 'EX', 15);

        return res.json({
            source: 'Database Utama (Cache Miss)',
            data: freshData
        });

    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
});

// Endpoint untuk Manual Cache Invalidation (Penghapusan Cache)
app.post('/api/data/invalidate', async (req, res) => {
    try {
        await redis.del('dashboard:data');
        res.json({ message: 'Cache berhasil di-invalidate (dihapus) secara manual!' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Menyediakan halaman dashboard frontend
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(3000, () => {
    console.log('Server berjalan di http://localhost:3000');
});